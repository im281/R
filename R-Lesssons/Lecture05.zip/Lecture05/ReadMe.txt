Getting started
1. Expand the zip file. One way is to open the zip file
   and drag and drop folder "Lecture05" to a
   convenient location such as your desktop
2. Open the folder "Lecture05"
3. In that folder, double click on the file "Lec05Start.Rproj"
   This will launch RStudio.
 
Installing the PubH6002 Package
1. In RStudio, go to the Packages tab and click install
2. Change "Install From:" to "Package Archive File (.tar.gz)"
3. Select the file PubH6002_0.24.tar.gz
4. Click the install button
