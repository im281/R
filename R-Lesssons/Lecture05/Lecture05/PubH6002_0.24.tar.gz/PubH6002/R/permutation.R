#' Simple permutation test
#' 
#' Permutation test for the difference in some sample statistic between two
#' groups. By default, compares sample means, but other statistics could be
#' used (e.g. median, sd, IQR, ...)
#' @param formula the formula, of the form y ~ group where y should be replaced
#' by the variable being tested and group should be replaced by the categorical
#' variable that defines the two groups
#' @param statistic the statistic to be compared (not in quotes!)
#' @param B the number of random permutations to use
#' @param plot if TRUE, the distribution of the differences under permutation will
#' be displayed
#' @param seed the random sampling seed used
#' @export
permutation.test = function(formula, statistic=mean, B=1000,
                            plot=FALSE, seed=1) {
  # Get the name of the statistic
  if (missing(statistic)) statName = deparse(formals()$statistic)
  else statName = deparse(match.call()$statistic)
  
  # Extract the components
  if (missing(formula) || (length(formula) != 3)) stop("'formula' missing or incorrect")
  m = match.call(expand.dots=FALSE)
  terms = as.character(m[-1][[1]])
  
  m = m[1:2]
  m[[1]] = quote(stats::model.frame)
  mf = eval(m, parent.frame())
  responseName = attr(attr(mf, "terms"), "response")
  
  response = unlist(mf[[responseName]])
  group  = as.character(unlist(mf[-responseName]))
  levels = sort(unique(group))
  
  if (length(levels)!=2) stop('expecting 2 levels')
  
  # Calculate the observed value
  ref1 = statistic(response[group==levels[1]]) 
  ref2 = statistic(response[group==levels[2]])
  ref = ref1-ref2
  
  # calculate the permutation distribution
  oneTest = function() {
    g = sample(group)==levels[1]
    stat = statistic(response[g]) - statistic(response[!g]) 
    return(stat)
  }
  
  z = c(ref,replicate(B-1,oneTest()))
  
  if (plot==TRUE) {
    # Display the permutation distribution
    hist(z,boxplot=FALSE,
         main=paste0('Permutation differences in ',statName,'s'))
    abline(v=ref,lty='dotted')
    text(ref,mean(par('usr')[3:4]),'Sample Difference',srt=90,adj=c(0.5,-0.75),
         cex=0.9,col=gray(0.4))
    
  }
  
  # Calculate the p-value
  m = length(z[abs(z)>=abs(ref)])
  n = length(z)
  p = m/n
  
  # Return
  out = list(
    statistic=structure(ref,names='Sample difference'),
    parameter=structure(B,names='permutations'),
    estimate=structure(c(ref1,ref2),names=paste(statName,' in group ',levels,sep='')),
    data.name=paste(terms[2],'by',terms[3]),
    p.value=p,
    alternative = "two.sided",
    null.value = structure(0,names=paste0('difference in ',statName,'s',sep='')),
    method=paste('Permutation test for a difference in ',statName,'s',sep='')
  )
  class(out) = 'htest'
  return(out)
}

# (permutation.test(age ~ type, statistic=IQR,plot=TRUE))
# (t.test(age ~ type))
