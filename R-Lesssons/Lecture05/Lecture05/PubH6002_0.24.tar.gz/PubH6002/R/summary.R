#' make a variable a factor if it looks like it is one
#' 
#' This function converts a variable to a factor if the variable is character,
#' or a numeric with no more than maxLevels levels. If called for a data frame,
#' it applies this operation to each of the variables in the data frame.
#' 
#' @param x a variable or a data frame
#' @param maxLevels the number of unique values beyond which a numeric variable 
#'   stops being considered a factor.
#' @keywords internal
toFactor = function(x, maxLevels=6) {
  
  toFactorOne = function(x) {
    if (is.factor(x)) return(x)  # nothing to do
    else if (!is.numeric(x)) return(factor(x))
    nLevels = length(unique(x))
    if (nLevels<=maxLevels) return(factor(x))
    else return(x)
  }
  
  if (is.data.frame(x)) x = as.data.frame(lapply(x,toFactorOne))
  else x = toFactorOne(x)
}

#' Calculate basic statistics on a numerical variable
#' 
#' @param x a variable to be summarized
#' @keywords internal
numericStats = function(x) {
  roundish = function(x) {
    wholePartLength = nchar(sprintf('%.0f',x))
    digits = getOption('digits')-wholePartLength
    if (digits>3) x = round(x,digits-1)
    return(x)
  }
  
  if (!is.numeric(x) | is.factor(x)) x = rep(NA,length(x))
  
  if (all(is.na(x))) {
    min = NA
    max = NA
    range = NA
    mean = NA
  }
  else {
    mean=mean(x,na.rm=TRUE)
    min = min(x,na.rm=TRUE)
    max = max(x,na.rm=TRUE)
    range = max-min
  }
  
  # return the summary stats
  stats = c(
    'N Total'   = length(x),
    'N Missing' = sum(is.na(x)),
    'N Obs' = length(x)-sum(is.na(x)),
    'Min' =roundish(min),
    'Q1(25%)'=roundish(as.numeric(quantile(x,0.25,na.rm=TRUE))),
    'Mean' =roundish(mean),
    'Median' = roundish(median(x,na.rm=TRUE)),
    'Q3(75%)'=roundish(as.numeric(quantile(x,0.75,na.rm=TRUE))),
    'Max' = roundish(max),
    'Std.Dev.'   = roundish(sd(x,na.rm=TRUE)),
    'IQR' = roundish(IQR(x,na.rm=TRUE)),
    'range' = roundish(range))
  
  labelWidth  = max(sapply(names(stats),nchar))
  statsWidths = max(sapply(as.character(stats),nchar))
  labels = sprintf(paste0('%-',labelWidth+1,'s'),names(stats))
  stats = paste(labels,
                sprintf(paste0('%-',statsWidths,'s'),stats))
  return(stats)
}

#' Calculate basic statistics on a categorical variable
#' 
#' @param x a variable to be summarized
#' @keywords internal
categoricalStats = function(x,maxRows=NULL) {
  if (!is.factor(x)) x = as.factor(x)
  
  # Basic table
  n = table(x,useNA='no')
  w = max(c(9,nchar(names(n))))
  fmt = paste0('%-',w,'s ')
  lev = sprintf(fmt,names(n))
  levFreqs = paste0(lev,n,' (',round(100*prop.table(n),1),'%)')
  
  # Header
  freqHeading = ' Frequencies '
  headingWidth = nchar(freqHeading)
  colWidth = max(c(nchar(levFreqs),w))
  headingLeftMargin = round((colWidth-headingWidth)/2)
  headingRightMargin = colWidth-headingWidth-headingLeftMargin 
  
  # calculate the iqv
  k = length(n)
  if (k<2) iqv=0 # no variability at all
  else iqv = (1-sum((n/sum(n))^2))*k/(k-1)
  
  # add contents
  np = c(paste0(sprintf(fmt,'N Total'),length(x)),
         paste0(sprintf(fmt,'N Missing'),sum(is.na(x))),
         paste0(sprintf(fmt,'N Obs'),sum(!is.na(x))),
         paste0(sprintf(fmt,'IQV'),round(iqv,4)),
         paste0(paste(rep('-',headingLeftMargin),collapse=''),
                freqHeading,
                paste(rep('-',headingRightMargin),collapse='')),
         levFreqs
  )

  if (!is.null(maxRows)) {
    # chop if too long
    if (length(np)>maxRows) {
      np = np[order(n,decreasing = TRUE)]
      omitted = length(np)-maxRows+1
      np = np[1:(maxRows-1)]
      
      np = c(np,paste0('(',omitted,' more omitted)'))
    }
  }  

  # add a bit of extra padding to separate the columns
  rightPadding = sprintf('%3s',' ')
  np = paste0(np, rightPadding)
  
  # Make sure we have full rows, otherwise sapply will
  # fail to make it into a matrix
  if (!is.null(maxRows)) {
    if (length(np)<maxRows) np = c(np,rep(' ',maxRows-length(np)))
  }
  
  # Force all entries to a constant widths
  width = max(nchar(np))
  np = sprintf(paste0('%-',width,'s'),np)
  
  return(np)
}

#' Produces a summary of a data frame
#' 
#' @param object the dataset
#' @param ... other options
#' @details The following are calculated for numeric variables
#' \describe{
#'  \item{N Total}{The number of observations}
#'  \item{N Missing}{The number of missing observations}
#'  \item{N Obs}{The number of non-missing observations}
#'  \item{Min}{The smallest value}
#'  \item{Q1(25\%)}{The lower quartile}
#'  \item{Mean}{The mean (average)}
#'  \item{Median}{The median}
#'  \item{Q3(75\%)}{The upper quartile}
#'  \item{Max}{The largest value}
#'  \item{Std.Dev.}{The standard deviation}
#'  \item{IQR}{The interquartile range (Q3-Q1)}
#'  \item{range}{The range (maximum - minimum)}
#' }
#' 
#' For categorical variables, the following are shown
#' #' \describe{
#'  \item{N Total}{The number of observations}
#'  \item{N Missing}{The number of missing observations}
#'  \item{N Obs}{The number of non-missing observations}
#'  \item{Frequencies}{The levels and their count and percentage}
#' }
#' 
#' If there are too many levels to fit in the summary, the most 
#' frequent levels are shown.
#' 
#' @keywords internal
#' @export summary.data.frame
summary.data.frame = function(object,...) {
  #get the call
  ds = deparse(match.call()$object)
  
  # if there are any factor-like variables, make them factors
  object = toFactor(object)

  # Separate numeric from factor. Is it numeric? numerical? I'm feeling
  # optimistical, so let's go with the fact that the -al word functions as an
  # adjective. Also, since I use categorical let's keep it symmetric. Nobody's
  # going to read this anyway. Hey. What are you looking at?
  numerical = sapply(object,is.numeric)
  
  nNumeric = sum(numerical)
  nOther   = sum(!numerical)
  
  out = list()
  out$.title = paste('Summary of data frame',ds)
  if (nNumeric>0) {
    section = sapply(object[,numerical,drop=FALSE],FUN=function(x) numericStats(x))
    section = as.data.frame(section)
    out[['Numerical variables']] = section
  }
  
  if (nOther>0) {
    section = sapply(object[,!numerical,drop=FALSE],FUN=function(x) categoricalStats(x,maxRows=13))
    section = dropEmptyTrailingRows(section)
    section = as.data.frame(section)
    out[['Categorical variables']] = section
  }
  class(out) = 'sections'
  return(out)
}

#' Produces a summary of a sectioned object
#' 
#' @param object object, assumed to be a list of sections
#' @param ... additional options, passed to the print function
#' 
#' @details 
#' The x object must be a named list of printable objects (i.e. ones that the
#' print() function can handle).  The section names are treated as section
#' titles. If there is a section called .title, it is take as the title of the
#' entire object and printed first.
#' @keywords internal
#' 
#' @export
print.sections = function(x,...) {
  if (!is.null(x$.title)) {
    cat(x$.title,'\n\n')
    x$.title = NULL
  }
  first = TRUE
  gap = 1
  
  for (sectionName in names(x)) {
    if (!first) cat('\n')
    cat(sectionName,'\n')
    
    # Nice printing of a section (expected to be a data frame)
    section = x[[sectionName,exact=TRUE]]
    
    m = format.data.frame(section, 
                          digits = getOption('digits'), 
                          na.encode = FALSE)
    
    
    # Convert to a character matrix with no row names
    m = as.matrix(m)
    rownames(m) = rep('',nrow(m))
    width = getOption('width')
    
    # Column header and row name widths
    colWidth = apply(rbind(colnames(m),m),2,function(col) max(nchar(col)))+gap
    colNames = sprintf(paste0('%-',colWidth-1,'s '),colnames(m))
    
    # Print panel by panel
    from = 1
    i = 0
    repeat {
      # Figure out how much will fit in this panel
      totWidth = cumsum(colWidth[from:ncol(m)])
      to   = from + which(totWidth>width)[1]-2
      if (is.na(to)) to=ncol(m)
      
      # Space between panels
      if (from>1) cat('\n')
      
      # Print it
      #cat('\n---------------------------------------\n')
      #cat('Printing ',from,'-',to,'\n',sep='')
      #cat('---------------------------------------\n')
      panel = m[,from:to,drop=FALSE]
      cNames = colNames[from:to]
      cat('  ',cNames,'\n',sep='')
      out = paste('  ',apply(panel,1,function(row) paste(row,collapse=' ')),collapse='\n',sep='')
      cat(out,'\n')
      #cat(paste(panel,collapse='\n'),'\n')
      #print.default(panel,quote=FALSE)
      
      # Advance to the next one
      from = to+1
      if (from>ncol(m)) break
      i = i+1
      if (i>5) break
    }
    
    first = FALSE
  }
}

#' Cleanup function that drops empty trailing character rows
#' 
#' This function expects to receive a character matrix. It drops any rows at the
#' bottom of the matrix that are completely empty, i.e. where all the columns
#' consist of empty or blank strings.
#' 
#' @param x character matrix
#' @return a matrix, possibly with fewer rows.
#' @keywords internal
dropEmptyTrailingRows = function(x) {
  allEmpty = function(row) length(grep('^\\s*$',row))==length(row)
  
  isEmpty = apply(x,1,allEmpty)
  lastNonEmpty = max(which(!isEmpty))
  
  x = x[1:lastNonEmpty,,drop=FALSE]
  return(x)
}

#' Prints a character matrix without quotes
#' 
#' @param x the matrix to be printed
#' @param ... additional arguments passed to the print function
#' @keywords internal
#' @export
print.unquotedMatrix = function(x,...) {
  class(x) = 'matrix'
  rownames(x) = rep('',nrow(x))
  base::print.default(x,quote=FALSE,...)
}

#' Summary of for a numeric object
#' 
#' This function handles numeric objects through the
#' numericStats function. Anything else is passed to
#' the standard summary.default.
#' 
#' @param object the object
#' @param ... other options
#' @keywords internal
#' 
#' @export summary.default
summary.default = function(object,...) {
  if (is.numeric(object)) {
    # it could be a factor coded as numeric
    object = toFactor(object)
    if (is.factor(object)) return(summary.factor(object))
    else {
      object = data.frame(object)
      colnames(object) = deparse(match.call()$object)
      out = sapply(object,FUN=function(x) numericStats(x))
      class(out) = 'unquotedMatrix'
      return(out)     
    }
  }
  else {
    base::summary.default(object,...)
  }
}

#' Summary of a factor
#' 
#' This function handles factor objects through the
#' categoricalStats function. 
#' 
#' @param object the dataset
#' @param ... other options
#' @keywords internal
#' 
#' @export summary.factor
summary.factor = function(object,...) {
  object = data.frame(object)
  colnames(object) = deparse(match.call()$object)
  out = sapply(object,FUN=function(x) categoricalStats(x))
  out = dropEmptyTrailingRows(out)
  rownames(out) = rep('',nrow(out))
  class(out) = 'unquotedMatrix'
  return(out)
}


#' Calculate the IQV for a categorical variable
#' 
#' @param x the categorical variable
#' @export
IQV = function(x) {
  n = table(x,useNA='no')
  k = length(n)
  if (k<2) iqv=0 # no variability at all
  else iqv = (1-sum((n/sum(n))^2))*k/(k-1)
  return(iqv)
}
