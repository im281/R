
#' Makes a dataset the default
#' 
#' The function sets the specified dataset as the current one, making
#' the variables within the dataset visible. 
#' 
#' @param data the dataset. If not provided, any current dataset is closed (it's
#' not deleted or altered in any way, but its variables are no longer visible)
#' @examples 
#' use(airquality)       # Makes airquality the current dataset
#' use()                 # drops the curent dataset (if any)
#' 
#' # Loading a subset
#' use(subset(airquality,Temp>80))
#' @export
use = function(data=NULL) {
  environmentName = 'defaultDs'
  
  # get the description
  datasetName = deparse(match.call()$data)
  
  if (is.null(data)) {
    if (environmentName %in% search()) {
      detach(pos=which(environmentName==search()))
      note('previous dataset closed. Its variables are not visible anymore.')
    }
    else note('there is no default dataset.')
  }
  else {
    if (!is.data.frame(data)) errorMsg('Can\'t use this. It\'s not a dataset')
    
    # detach previous copy and attach this one
    tryCatch({
      previousFound = FALSE
      loaded = FALSE
      if (environmentName %in% search()) {
        previousFound = TRUE
        detach(pos=which(environmentName==search()))
      }
      attach(data,name=environmentName,pos=2)
      loaded=TRUE
    },
    error=function(e) cat(.makeMessage(e))
    )
    
    if (loaded) {
      if (previousFound) note('previous dataset closed. Its variables are not visible anymore.')
      note('the variables in ',datasetName,' are now visible.')
    }
    else {
      note('there was a problem loading ',datasetName,'.')
      if (previousFound) note('Continuing to use the previous dataset.')
      else note('There is no dataset in use.')
    }
  }
}