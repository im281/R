#' Add theme arguments to an argument list
#' 
#' @param args the function arguments
#' @param style either the name of the style or a style list
#' 
#' @details 
#' The function augments the arguments with values from the specified style.
#' Arguments specified in args are not overwritten.
#' @keywords internal
mergeTheme = function(args, style) {
  # remove the style option if it's there
  args$style = NULL
  
  # fetch the style
  if (is.character(style)) style = getStyle(style[1])
  if (is.null(style)) return(args)
  
  # pick any options not already in args
  argNames = names(args)
  if (is.null(argNames)) keep = names(style)
  else keep = setdiff(names(style),argNames)
  
  # return the updated arguments
  return(append(args,style[keep]))  
}

#' Create a mosaic plot
#' 
#' Creates a mosaic plot
#' 
#' @param formula a formula of the form \code{y ~ x} where \code{y} should
#'   be replaced by the y variable and \code{x} should be replaced by the x
#'   variable.
#' @param style the plot style
#' @param ... other options. For a list of all options, see the 
#' \link[graphics]{mosaicplot} function in the package graphics.
#' 
#' @seealso
#' This function augments the usual \link[graphics]{mosaicplot} 
#' function in the graphics package.  
#' 
#' @export
mosaicplot = function(formula,style='mosaicplot',...) {
  if (missing(formula)) {
    warningMsg('You didn\'t specify what should be plotted by mosaicplot(). Doing nothing.')
    return(invisible())
  }
  
  # construct the colors
  style = getStyle(style)
  
  # supply theme defaults
  args = as.list(match.call(expand.dots=TRUE))[-1]

  # figure out the colors
  formula = args[[1]]
  callStyle = class(eval(formula))
  if (callStyle!='formula') errorMsg('Expecting a formula of the form y ~ x')

  nColors = length(unique(eval.parent(formula[[3]])))
  if (nColors==2) colors = c(style$grayColor,style$lowColor)
  else colors = colorRampPalette(c(style$lowColor,style$highColor))(nColors)
  
  # now fix the style object
  style$lowColor = style$highColor = style$grayColor = NULL
  style$col = colors
  args = mergeTheme(args,style)
 
  # Run the function
  do.call(get("mosaicplot", asNamespace("graphics")),args, envir=parent.frame())
}

#' Create a plot for two variables
#' 
#' If the x and y variables are numeric, creates a scatter plot, optionally 
#' adding a smooth curve. If x or y are factors, appropriate plots are selected.
#' 
#' @param formula a sinble variable, or a formula of the form \code{y ~ x} where
#' \code{y} should be replaced by the y variable and \code{x} should be
#' replaced by the x variable.
#' @param style the plot style
#' @param show.smooth if TRUE a smooth line is added to the scatterplot. If
#' either x or y is a factor, this option has no effect.
#' @param ... other options. For a list of all options, see the 
#' \link[graphics]{plot} function in the package graphics.
#' @param as.is if TRUE, bypasses some of the fancier guessing to determine the
#' type of plot to be produced, and tends to produce scatterplots if possible.
#' 
#' @details 
#' Plot produces several graphics, depending on the arguments it receives.
#' Specifically, these are the plots produced:
#' \describe{
#' \item{a single numeric}{histogram}
#' \item{a single factor}{barplot}
#' \item{numeric ~ numeric}{scatterplot}
#' \item{numeric ~ factor}{boxplot}
#' \item{factor ~ numeric}{horizontal boxplot}
#' \item{factor ~ factor}{mosaic plot}
#' }
#' @seealso
#' This function augments the usual \link[graphics]{plot} 
#' function in the graphics package.
#' @export
plot = function(formula,
                style=ifelse(show.smooth,'scatter.smooth','plot'),
                show.smooth=FALSE,
                as.is=FALSE,...) {
  
  if (missing(formula)) {
    warningMsg('You didn\'t specify what should be plotted by plot(). Doing nothing.')
    return(invisible())
  }
  
  # Heuristically decide if x is a factor
  checkIfFactor = function(x,maxUnique=6) {
    if (is.factor(x)) return(list(isFactor=TRUE,makeFactor=FALSE))
    else if (is.character(x)) return(list(isFactor=TRUE,makeFactor=TRUE))
    else {
      nUnique = length(unique(x))
      if ((nUnique<=maxUnique) & (nUnique+maxUnique<length(x))) return(list(isFactor=TRUE,makeFactor=TRUE))
      else return(list(isFactor=FALSE,makeFactor=FALSE))
    }
  }
  
  # Construct the appropriate call
  makeFormula = function(y,yMakeFactor,x,xMakeFactor) {
    y = deparse(y)
    x = deparse(x)
    if (yMakeFactor) y = paste0('factor(',y,')')
    if (xMakeFactor) x = paste0('factor(',x,')')
    formula = paste(y,x,sep='~')
    return(formula)
  }
  
  # get and clean the arguments
  args = as.list(match.call(expand.dots=TRUE))[-1]
  args$show.smooth=NULL
  args$as.is=NULL
  
  # un-name the first argument to allow it to be whatever it needs 
  # to be 
  names(args)[1] = ''

  # Try to route it intelligently
  if (length(args[[1]])==1) isFormula=FALSE
  else isFormula = as.character(args[[1]][[1]]=='~')
  
  if (as.is) plotFunction = get("plot", asNamespace("graphics"))
  else if (isFormula) {
    # a formula: take it apart and rebuild
    formula = args[[1]]
    if (length(formula)!=3) errorMsg('Incorrect formula. Expecting something like y ~ x')

    # grab the x and y variables and check if they're factor variables,
    # or at least factor-like variables
    yVar = formula[[2]]
    xVar = formula[[3]]
    y = checkIfFactor(eval.parent(yVar))
    x = checkIfFactor(eval.parent(xVar))

    # Look at the various cases
    if (y$isFactor & x$isFactor) {
      # cat('factor-factor. Calling spineplot\n')
      plotFunction = 'mosaicplot'
      style = 'none'
    }    
    else if (y$isFactor) {
      # cat('factor-numeric. Calling boxplot (reversed)\n')
      plotFunction = 'boxplot'
      style = 'none'
      args[[1]] = as.formula(makeFormula(xVar,x$makeFactor,yVar,y$makeFactor),
                             env=parent.frame())
      args$horizontal = TRUE
    }
    else if (x$isFactor) {
      # cat('numeric-factor. Calling boxplot\n')
      plotFunction = 'boxplot'
      style = 'none'
    }
    else {
      # cat('numeric-numeric. Calling plot\n')
      if (show.smooth) plotFunction = get("scatter.smooth", asNamespace("stats"))
      else plotFunction = get("plot", asNamespace("graphics"))
    }
  }
  else {
    # a single object
    xVar = args[[1]]
    x = checkIfFactor(eval.parent(xVar))
    if (is.data.frame(eval.parent(xVar))) {
      plotFunction = 'pairs'
      style = 'none'
    }
    else if (x$isFactor) { 
      # cat('Single categorical - barplot')
      plotFunction = 'barplot'
      style = 'none'
    }
    else {
      # cat('Single numeric - hist&boxplot')
      plotFunction = 'hist'
      style='none'
    }
  }
  
  # Add the appropriate style
  args = mergeTheme(args,style)
  
  # Run the function
  do.call(plotFunction,args, envir=parent.frame())
}

#' Draw a box plot
#' 
#' Draw a box and whiskers plot
#' 
#' @param formula either a single variable (for a single boxplot), or a formula
#'   a formula of the form \code{y ~ x} where \code{y} should be replaced by the
#'   y variable and \code{x} should be replaced by the x variable. In the case
#'   of a formula, one boxplot of y will be drawn for each value of x.
#' @param style the plot style
#' @param ... other options. For a list of all options, see the 
#' \link[graphics]{boxplot} function in the package graphics.
#' 
#' @seealso
#' This function augments the usual \link[graphics]{boxplot} 
#' function in the graphics package. 
#' @export
boxplot = function(formula,style='boxplot',...) {
  if (missing(formula)) {
    warningMsg('You didn\'t specify what should be plotted by boxplot(). Doing nothing.')
    return(invisible())
  }
  
  # supply theme defaults
  args = mergeTheme(as.list(match.call(expand.dots=TRUE))[-1],style)

  # remove the name of the first argument since the name is
  # different in the different versions of boxplot.
  names(args)[1] = ''
  
  # Run the function
  do.call(get("boxplot", asNamespace("graphics")),args, envir=parent.frame())
}

#' Draw a histograms
#' 
#' Draws a histogram of the given data values, optionally adding a box plot
#' under the histogram.
#' 
#' @param x a single variable for which a histogram to be drawn/
#' @param style the graphical style to be used.
#' @param boxplot if TRUE, a box plot is added below the histogram. If
#' it's FALSE, the box plot is omitted.
#' @param show.n if TRUE, the n's are shown on top of the bars. If it's
#' FALSE, the n's are omitted.
#' @param ... other options. For a list of all options, see the 
#'   \link[graphics]{hist} and \link[graphics]{boxplot} functions in the package
#'   graphics.
#' 
#' @seealso
#' This function augments the usual \link[graphics]{hist} 
#' function in the graphics package. 
#' 
#' @export
hist = function(x,style=c('hist','boxplot'), boxplot=TRUE,show.n=TRUE,...) {
  if (missing(x)) {
    warningMsg('You didn\'t specify what should be plotted by hist(). Doing nothing.')
    return(invisible())
  }

  # grab and clean up the parameters
  args = as.list(match.call(expand.dots=TRUE))[-1]
  args$boxplot=NULL
  args$show.n =NULL


  # If necessary, prepare the layout
  if (boxplot) {
    # Prepare to reset graphic parameters on exit
    savePar = par(no.readonly=TRUE)
    on.exit(par(savePar))
    layout(mat = matrix(c(1,2),2,1, byrow=TRUE),heights=c(3,1))
    par(mar=c(0.1, 4.1, 3.1, 2.1))
  }
  
  # Generate the histogram using the function from package graphics,
  # supplying the theme defaults
  histArgs = mergeTheme(args,style[1])
  
  if (boxplot) {
    histArgs$xlab=''  # the x label always goes on boxplot
    histArgs$xaxt='n'
  }
  
  #cat('Calling graphics::hist\n')
  
  histFunction = get("hist", asNamespace("graphics"))
  histOut = do.call(histFunction,histArgs, envir=parent.frame())
  

  # Add the n's if necessary
  if (show.n) {
    text(histOut$mids,histOut$counts,histOut$counts,
         pos=3,xpd=NA,col=gray(0.4),cex=0.9)
  }
  
  # Run the function
  if (boxplot) {
    # Produce the boxplot Careful in selecting
    # arguments
    bxpArgs = mergeTheme(args,style[2])
    bxpArgs$x = args$x
    bxpArgs$formula = args$x
    bxpArgs$ylab=''     # the ylabel always goes on hist
    bxpArgs$horizontal=TRUE
    bxpArgs$ylim=range(x,na.rm=TRUE)
    bxpArgs$frame=FALSE
    bxpArgs$yaxt='n'
    bxpArgs$main=''
    bxpArgs$style=style[2]
    
    boxplotFunction = get("boxplot", asNamespace("graphics"))
    
    par(mar=c(4.5, 4.1, 0.1, 2.1))
    do.call(boxplotFunction,bxpArgs, envir=parent.frame())
    
    # restore layout
    layout(1)
    
  }

  return(invisible(histOut))
}
#
#source('R/theme.R')
#setTheme(bw=FALSE)

#b=hist(rnorm(100),boxplot=FALSE)
#abline(v=1,lwd=3,col='blue')

#abline(v=1)
# x = airquality$Ozone
# hist(x^2)

#hist(runif(100))

#' points
#' 
#' Adds points to an existing plot
#' 
#' @param formula a formula of the form \code{y ~ x} where \code{y} should
#'   be replaced by the y variable and \code{x} should be replaced by the x
#'   variable.
#' @param style the plot style
#' @param ... other options. For a list of all options, see the 
#' \link[graphics]{points} function in the package graphics.
#' 
#' @seealso
#' This function augments the usual \link[graphics]{points} 
#' function in the graphics package.
#'
#' @export
points = function(formula,style='points',...) {
  if (missing(formula)) {
    warningMsg('You didn\'t specify what should be plotted by points(). Doing nothing.')
    return(invisible())
  }
  
  # supply theme defaults
  args = mergeTheme(as.list(match.call(expand.dots=TRUE))[-1],style)
  
  # Run the function
  do.call(get("points", asNamespace("graphics")),args, envir=parent.frame())
}

#' lines
#' 
#' Adds lines to an existing plot
#' 
#' @param formula a formula of the form \code{y ~ x} where \code{y} should
#'   be replaced by the y variable and \code{x} should be replaced by the x
#'   variable.
#' @param style the plot style
#' @param ... other options. For a list of all options, see the 
#' \link[graphics]{lines} function in the package graphics.
#' 
#' @seealso
#' This function augments the usual \link[graphics]{lines} 
#' function in the graphics package.
#'
#' @export
lines = function(formula,style='lines',...) {
  if (missing(formula)) {
    warningMsg('You didn\'t specify what should be plotted by lines(). Doing nothing.')
    return(invisible())
  }
  
  # supply theme defaults
  args = mergeTheme(as.list(match.call(expand.dots=TRUE))[-1],style)
  
  # Run the function
  do.call(get("lines", asNamespace("graphics")),args, envir=parent.frame())
}

#' Bar plot for categorical data
#' 
#' Summarize a categorical variable as a bar plot
#' 
#' @param x the (categorical) variable to be plotted
#' @param show.n whether to show the n's above the histogram bars
#' @param style the plot style
#' @param ... other options. For a list of all options, see the 
#' \link[graphics]{barplot} function in the package graphics.
#' 
#' @seealso
#' This function augments the usual \link[graphics]{barplot} 
#' function in the graphics package.
#' 
#' @export
barplot = function(x,style='barplot',show.n=TRUE,...) {
  if (missing(x)) {
    warningMsg('You didn\'t specify what should be plotted by barplot(). Doing nothing.')
    return(invisible())
  }
  
  # supply theme defaults
  args = mergeTheme(as.list(match.call(expand.dots=TRUE))[-1],style)
  names(args)[1] = 'height'
  args$show.n = NULL
  
  # if the first argument is not a table, make it one
  x = eval.parent(args[[1]])
  ok = is.table(x) | is.matrix(x)
  
  if (!ok) args[[1]] = eval.parent(parse(text=paste0('table(',deparse(args[[1]]),')')))

  # Run the function
  b = do.call(get("barplot", asNamespace("graphics")),args, envir=parent.frame())
  
  if (show.n) {
    # add n's
    n = table(eval.parent(x))
    text(b,n,paste('N=',n),pos=3,xpd=NA,col=gray(0.4),cex=0.9)
  }
  return(invisible(b))
}


# set.seed(1)
# n = 60
# x = runif(n)
# hist(x,
#      boxplot=FALSE,
#      show.n=FALSE)
# y = rnorm(n)
# f3 = sample(1:3,20,replace=TRUE)
# f2 = sample(1:2,20,replace=TRUE)
# barplot(f2)
# summary(factor(f2))
# plot(f3~f2,xlab='Test variable',main='Example',sub='12-5-2016')
#debug(y~f1)
# set.seed(1)
# x = round(runif(10)*2)
# y = round(runif(10)*3)
# #print(table(x,y))
# spineplot(y ~ factor(x))

#spineplot(factor(x),y)
# x = runif(20)
# y = runif(20)+x
# plot(y~x)

# x = runif(20)
# y = runif(20)+x
# scatterPlot(y~x,showSmooth = TRUE)

# set.seed(3)
# x = round(runif(10)*2)
# y = rnorm(10)
# boxplot(y ~ x)
# boxplot(y)


# x = runif(20)
# y = runif(20)+x
# z = runif(20)+ 0.5*x
# scatterPlot(y~x,showSmooth = TRUE)
# points(z~x,bg='red')