#' Combine several levels of a factor
#' 
#' @param x the categorical variable
#' @param label the label from the combined level. If this is NA, the categories are all set to NA.
#' @param ... the categories to combine, as quoted strings
#' @export
#' @examples 
#' # combine June, July and August (6,7,8) into a single
#' # category called "summer"
#' newMonth = combineLevels(airquality$Month,6,7,8,label='summer')
combineLevels = function(x,...,label='Combined') {
  # prepare x
  x = as.character(x)
  
  # Extract the levels to be combined
  oldLevels = as.list(match.call(expand.dots = TRUE))[-1]
  oldLevels$x = NULL
  oldLevels$new.level=NULL
  oldLevels = unlist(oldLevels)
  
  # replace
  x [x %in% oldLevels] = label
  
  # reconstruct
  x = factor(x)
  return(x)
}
