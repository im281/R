#' Influence plot
#' 
#' @param x the variable or the fit from a regression model
#' @param stat one of 'mean', 'median', or 'sd' (not used for fit objects)
#' @param xlab (optional) the x label for the plot
#' @param main (optional) the title of the plot
#' @param label.outliers if TRUE, outliers are labelled by observation number
#' @note If x is the result from a fit from a regression model, there will be an
#'   influence plot for each coefficient in the model
#' @examples 
#' influencePlot(airquality$Ozone, mean)
#' @export
influencePlot = function(x=NULL,
                         stat=NULL,
                         xlab='Observation number',
                         main='',
                         label.outliers=TRUE) {
  
  if (missing(x)) {
    warningMsg('You didn\'t specify what should be plotted by influencePlot(). Doing nothing.')
    return(invisible())
  }
  
  # is it a fit object?
  if (inherits(x,'lm')) {
    # Get the dfbetas
    dfb   = dfbetas(x)
    terms = colnames(dfb)
    p     = ncol(dfb)
    n     = nrow(dfb)
    
    # prepare to plot
    for (j in 1:p) {
      if (terms[j] != '(Intercept)') {
        plot(dfb[,j],
             xlab=xlab,
             ylab=paste('Effect of coefficient for',terms[j]) ,
             main=paste('Influence plot for',terms[j]),
             as.is = TRUE
        )
        abline(h=c(-2,2)/sqrt(n),lty=2)
        
        if (label.outliers) {
          # Label the points outside
          out = abs(dfb[,j])>2/sqrt(n)
          text(which(out),dfb[out,j],paste0('#',which(out)),pos=4,
               cex=0.9,xpd=NA,col=gray(0.3))
        }
      }
      
    }
  }
  else {
    yVarName = deparse(match.call()$x)
    statName = deparse(match.call()$stat)
    validStats = c('mean','median', 'sd', 'min', 'max')
    
    # sanity checks
    if (is.null(stat)) errorMsg('Specify a statistic after the variable name. It can be one of ',
                              paste(validStats,collapse=', '))
    
    n = length(x)
    if (n<2) errorMsg('this variable has fewer than 2 values')
    
    # check what the statistic is
    if (!(statName %in% validStats))
      errorMsg('Expecting one of ',paste(validStats,collapse=', '),
             '. "',statName,'" is not of them')
    
    # get the full and drop-one values
    full.stat = rep(stat(x[!is.na(x)]),n)
    drop.one  = lapply(1:n, function(i) {
      x = x[-i]
      return(stat(x[!is.na(x)]))
    })
    
    drop.one = unlist(drop.one)
    
    # plot
    delta = drop.one-full.stat
    
    if (xlab=='') xlab=paste('Observation number for',yVarName)
    
    index = 1:n
    plot(delta~index,
         as.is=TRUE,
         ylab=paste('Change in',statName),
         xlab=xlab,
         main=main
    )
    abline(h=0,lty=2)
    
    # Print a summary
    worstAbs = sort(unique(abs(delta)),decreasing = TRUE)[1:5]
    worst = sort(unique(delta[which(abs(delta) %in% worstAbs)]))
    
    worst = signif(worst,5)
    if (length(worst)==1) wording = 'worst value'
    else wording = paste('worst',length(worst),'values')
    
    cat('Influence on the ',statName,
        ', ',wording,': ',
        paste(worst,collapse=', '),'\n',sep='')
    
    # Add delta axis
    drop.one.ticks = pretty(drop.one)
    axis(4,at=drop.one.ticks-full.stat[1],labels = drop.one.ticks)
    mtext(side=4,text=paste('Drop-one value for',statName),line=3)
    
    if (label.outliers) {
      # use boxplot stats to identify the outliers
      out.y = boxplot.stats(delta,coef = 2.5)$out
      if (length(out.y)>0) {
        out.x = which(delta %in% out.y)
        out.y = delta[out.x]
        text(out.x,out.y,paste0('#',out.x),pos=4,xpd=NA,col=gray(0.3),cex=0.8)
      }
      #else cat('Note: no outliers detected\n')
    }
  }
}


