#' print an error message and strop
#' 
#' This is an internal function to print an error message
#' @param ... the error message
#' @keywords internal
errorMsg = function(...) stop(...,call.=FALSE)


#' print a note
#' 
#' This is an internal function to print an error message
#' @param ... the note
#' @keywords internal
note = function(...) cat('Note: ',...,'\n',sep='')

#' print a warning
#' 
#' This is an internal function to print an warning message
#' @param ... the note
#' @keywords internal
warningMsg = function(...) cat('Warning: ',...,'\n',sep='')

