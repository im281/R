#' Tasks before attaching
#' 
#' This is called before the package environment is sealed. We use this 
#' primarily to create .conflicts.OK to suppress the printing messages about
#' things being masked
#' 
#' @param libname	a character string giving the library directory where the
#'   package defining the namespace was found.
#' @param pkgname	 a character string giving the name of the package.
#' @keywords internal
.onAttach = function(libname, pkgname){
  # Suppress masking messages. The variable .conflicts.OK must exist
  # in the package environment (its value is not used)
  assign('.conflicts.OK',TRUE,paste0('package:',pkgname))
  
  # set the default theme. By default, we'll use color
  PubH6002::setTheme(bw=FALSE)
  
  # Set some knitr defaults
  PubH6002::noDoubleHash()
  
  # Echo a message so the students know it worked
  version = utils::packageVersion("PubH6002")
  packageStartupMessage("The PubH6002 package (version ",version,") is now available\n")
  
}