#' Define the default appearance for functions
#' 
#' @param bw if TRUE, the colors in the theme are converted to gray scale
#' 
#' @examples 
#' setTheme()         # color version
#' setTheme(bw=TRUE)  # black and white version
#' @export
setTheme = function(bw=FALSE) {
  # GWU Standard colors
  .GWColors = list(
    corePrimary=list(blue='#004065',gold='#c8b18b'),
    coreAccents=list(blue='#0096d6',gold='#ffeebb'),
    secondary=list(yellow='#ffc82e',brown='#a55121',aqua='#008367',green='#7ac143',red='#e31937'),
    other=list(darkBlue='#002942',white='#ffffff',
               lightGray='#E6E6E6',darkGray='#4D4D4D',
               medGray='#808080')
    )
  
  # transparency function
  tr = function(col,opacity='99') paste0(col,'99')
  
  # if bw=TRUE, desaturate the color
  # @param color the desired color
  setSaturation = function(color) {
    if (bw) {
      asHSV = rgb2hsv(col2rgb(color))
      color = hsv(h=asHSV[1],s=0,v=asHSV[3])
    }
    return(color)
  }
  
  # create the theme. Note that the theme specifies
  # defaults to be used with various functions.
  theme = list(
    'boxplot' = list(
      col    = setSaturation(.GWColors$coreAccents$blue),
      border = setSaturation(.GWColors$corePrimary$blue),
      outbg  = setSaturation(.GWColors$coreAccents$blue),
      outcol = setSaturation(.GWColors$corePrimary$blue),
      outpch = 21,
      main   = ''
    ),
    'hist' = list(
      col    = setSaturation(.GWColors$corePrimary$gold),
      border = .GWColors$other$darkGray,
      main   = ''
    ),
    'frame' = list(
      col = .GWColors$other$darkGray
    ),
    'plot' = list(
      col = setSaturation(.GWColors$corePrimary$blue),
      bg  = setSaturation(.GWColors$coreAccents$blue),
      pch   = 21
    ),
    'scatter.smooth' = list(
      col = tr(setSaturation(.GWColors$corePrimary$blue)),
      bg  = tr(setSaturation(.GWColors$coreAccents$blue)),
      pch = 21,
      lpars = list(col=.GWColors$corePrimary$blue,
                   lwd=2)
    ),
    'points' = list(
      col = setSaturation(.GWColors$corePrimary$blue),
      bg  = setSaturation(.GWColors$coreAccents$blue),
      pch = 21
    ),
    'points.tr' = list(
      bg  = tr(setSaturation(.GWColors$corePrimary$gold)),
      col = tr(.GWColors$other$medGray),
      pch = 21
    ),
    'lines' = list(
      col = tr(setSaturation(.GWColors$corePrimary$blue))
    ),
    'mosaicplot' = list(
      # The next 3 options are converted to col on the fly,
      # depending on the number of colors in the plot
      highColor = .GWColors$corePrimary$blue,
      lowColor  = .GWColors$coreAccents$blue,
      grayColor = .GWColors$other$lightGray,
      main      = ''
    ),
    'barplot' = list(
      col    = setSaturation(.GWColors$coreAccents$blue),
      border = setSaturation(.GWColors$corePrimary$blue)
    )
  )
  
  # Stash it in the options
  options('functionDefaults'=theme)
}

#' Get the default appearance for functions
#'
#' @param style the name of the style. If NULL, all styles are
#' returned. 
#' @keywords internal
getStyle = function(style=NULL) {
  if (is.null(style)) return(getOption('functionDefaults'))
  else return(getOption('functionDefaults')[[style]]) 
} 