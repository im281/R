#' Allow knit to complete with errors
#'
#' Place this function near the top of your R document, after
#' the \code{library(PubH6002)} function. If it's present,
#' any errors in the R file will show up in the notebook instead of
#' causing the process of compiling the notebook to fail. If you use
#' this function, be sure to check the notebook for errors!
#' 
#' @examples
#' # if you want the notebook to compile despite any errors:
#' library(PubH6002)
#' allowErrorsInNotebook()
#' 
#' # To make the notebook fail in case of errors, delete
#' # the function, or make it a comment:
#' library(PubH6002)
#' # allowErrorsInNotebook()
#' 
#' @export
allowErrorsInNotebook = function() {
  if (!is.null(getOption('knitr.in.progress'))) {
    knitr::opts_chunk$set(error=TRUE,warning=TRUE)
    cat('Note: R errors will not cause the notebook compilation to fail.')
  }
}

#' Requests that knit stop on errors
#'
#' This function cancels the effect of \code{allowErrorsInNotebook()}.
#' It can appear anywhere after the \code{library(PubH6002)} statement.
#' Any errors below it will cause the compilation process to fail.
#' 
#' @examples
#' # if you want the notebook to compile despite any errors:
#' library(PubH6002)
#' allowErrorsInNotebook()
#' 
#' # some stuff here
#' stopIfErrorsInNotebook()
#' 
#' @export
stopIfErrorsInNotebook = function() {
  if (!is.null(getOption('knitr.in.progress'))) {
    knitr::opts_chunk$set(error=FALSE,warning=FALSE)
    cat('Note: R errors will cause the notebook compilation to fail.')
  }
}

#' Nicer output from functions
#' 
#' This supresses the '##' that normally print in front
#' of function output
#' 
#' @keywords internal
#' @export
noDoubleHash = function() {
  if (!is.null(getOption('knitr.in.progress'))) {
    knitr::opts_chunk$set(comment='') 
  }  
}
