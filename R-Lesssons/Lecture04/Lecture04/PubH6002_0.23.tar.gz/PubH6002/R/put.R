put = function(...) {
  args = as.list(match.call(expand.dots = TRUE))[-1]
  argNames = names(args)
  for (i in 1:length(args)) {
    arg = args[[i]]
    name = deparse(arg)
    value = eval.parent(arg)
    if (class(value) %in% c('logical','character','numeric')) {
      if (length(value)>5) cat(name,'=',value[1:5],' ...\n')
      else cat(name,'=',value,'\n')
    }
    else {
      cat(name,':\n',sep='')
      print(value)
    }
  }
}

