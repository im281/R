#' print an error message and strop
#' 
#' This is an internal function to print an error message
#' @param ... the error message
#' @keywords internal
errorMsg = function(...) stop(...,call.=FALSE)

#' Makes a dataset the default
#' 
#' The function sets the specified dataset as the current one, making
#' the variables within the dataset visible. 
#' 
#' @param data the dataset. If not provided, any current dataset is closed (it's
#' not deleted or altered in any way, but its variables are no longer visible)
#' @examples 
#' use(airquality)       # Makes airquality the current dataset
#' use()                 # drops the curent dataset (if any)
#' 
#' # Loading a subset
#' use(subset(airquality,Temp>80))
#' @export
use = function(data=NULL) {
  environmentName = 'defaultDs'
  
  if (is.null(data)) {
    if (environmentName %in% search()) {
      detach(pos=which(environmentName==search()))
      cat('Note: previous dataset closed. Its variables are not visible anymore.\n')
    }
    else cat('Note: there is no default dataset.\n')
  }
  else {
    if (!is.data.frame(data)) errorMsg('Can\'t use this. It\'s not a dataset')
    
    # detach previous copy and attach this one
    tryCatch({
      previousFound = FALSE
      loaded = FALSE
      if (environmentName %in% search()) {
        previousFound = TRUE
        detach(pos=which(environmentName==search()))
      }
      attach(data,name=environmentName,pos=2)
      loaded=TRUE
    },
    error=function(e) cat(.makeMessage(e))
    )
    
    if (loaded) {
      if (previousFound) cat('Note: the variables in this dataset are now visible\n',sep='')
      else cat('Note: the variables in this dataset are now visible\n',sep='')
    }
    else {
      cat('Note: there was a problem loading this dataset. ')
      if (previousFound) cat('Continuing to use the previous dataset.\n',sep='')
      else cat('There is no dataset in use.\n',sep='')
    }
  }
}
